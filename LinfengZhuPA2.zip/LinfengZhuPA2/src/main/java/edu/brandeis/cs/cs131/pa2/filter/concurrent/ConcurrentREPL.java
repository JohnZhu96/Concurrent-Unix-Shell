package edu.brandeis.cs.cs131.pa2.filter.concurrent;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.*;

import edu.brandeis.cs.cs131.pa2.filter.Message;

/**
 * The main implementation of the REPL loop (read-eval-print loop). It reads
 * commands from the user, parses them, executes them and displays the result.
 */
public class ConcurrentREPL {

    /**
     * pipe string
     */
    static final String PIPE = "|";

    /**
     * redirect string
     */
    static final String REDIRECT = ">";

    static final String BACKGROUND = "&";

    static CopyOnWriteArrayList<String> futures = new CopyOnWriteArrayList<>();

    static ConcurrentHashMap<String, Future<String>> futuresMap = new ConcurrentHashMap<>();

    static ConcurrentHashMap<String, String> cmdMap = new ConcurrentHashMap<>();

    /**
     * The main method that will execute the REPL loop
     *
     * @param args not used
     */
    public static void main(String[] args) {
        synchronized (ConcurrentREPL.class) {
            ExecutorService executorService = Executors.newFixedThreadPool(10);
            Scanner consoleReader = new Scanner(System.in);
            System.out.print(Message.WELCOME);

            while (true) {

                System.out.print(Message.NEWCOMMAND);

                // read user command, if its just whitespace, skip to next command
                String cmd = consoleReader.nextLine();
                if (cmd.trim().isEmpty()) {
                    continue;
                }

                // exit the REPL if user specifies it
                if (cmd.trim().equals("exit")) {
                    break;
                }

                if (cmd.trim().length() - 1 == cmd.trim().lastIndexOf("&")) {

                    try {
                        // parse command into sub commands, then into Filters, add final PrintFilter if
                        // necessary, and link them together - this can throw IAE so surround in
                        // try-catch so appropriate Message is printed (will be the message of the IAE)
                        List<ConcurrentFilter> filters = ConcurrentCommandBuilder.createFiltersFromCommand(cmd);

                        // call process on each of the filters to have them execute

                        Callable<String> process = () -> {
                            Thread.sleep(1000);
                            for (ConcurrentFilter filter : filters) {
                                filter.process();
                            }
                            return cmd;
                        };
                        Future<String> future = executorService.submit(process);
                        if (!"repl_jobs".equals(cmd) && !cmd.startsWith("kill")) {
                            futures.add(cmd);
                            futuresMap.put(cmd, future);
                        }
                    } catch (InvalidCommandException e) {
                        System.out.print(e.getMessage());
                    }
                } else {
                    try {
                        // parse command into sub commands, then into Filters, add final PrintFilter if
                        // necessary, and link them together - this can throw IAE so surround in
                        // try-catch so appropriate Message is printed (will be the message of the IAE)
                        List<ConcurrentFilter> filters = ConcurrentCommandBuilder.createFiltersFromCommand(cmd);

                        // call process on each of the filters to have them execute
                        for (ConcurrentFilter filter : filters) {
                            filter.process();
                        }
                    } catch (InvalidCommandException e) {
                        System.out.print(e.getMessage());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            executorService.shutdown();

            try {
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.print(Message.GOODBYE);
            consoleReader.close();
            futures.clear();
        }
    }

    public static File writeFile(String filename, String content) {

        try {
            File file = new File(filename);
            if (!file.exists()){
                file.createNewFile();
            }
            if (!file.exists() && !content.isEmpty()) {
                FileWriter writer = new FileWriter(file);
                writer.write(content);
                writer.close();
            }
            return file;
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
}
