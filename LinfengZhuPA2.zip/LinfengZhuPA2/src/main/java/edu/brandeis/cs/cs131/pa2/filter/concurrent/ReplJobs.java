package edu.brandeis.cs.cs131.pa2.filter.concurrent;

import edu.brandeis.cs.cs131.pa2.filter.CurrentWorkingDirectory;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReplJobs extends ConcurrentFilter {
    private String jobNumber;

    public ReplJobs(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public ReplJobs() {
    }

    @Override
    public void process() throws IOException {
        if (jobNumber != null){
            int idx = Integer.parseInt(jobNumber) - 1;
            if (ConcurrentREPL.futures.size() > idx && ConcurrentREPL.futuresMap.containsKey(ConcurrentREPL.futures.get(idx))){
                ConcurrentREPL.futuresMap.get(ConcurrentREPL.futures.get(idx)).cancel(true);
                String fileName = extractFileName(ConcurrentREPL.futures.get(idx));
                new File(CurrentWorkingDirectory.get() + CurrentWorkingDirectory.getPathSeparator() + fileName).createNewFile();
                ConcurrentREPL.futures.set(idx, null);
                jobNumber = null;
                return;
            }
        }
        for (int i = 0; i < ConcurrentREPL.futures.size(); i++) {
            if (ConcurrentREPL.futures.get(i) != null) {
                System.out.print("\t" + (i + 1) + ". " + ConcurrentREPL.futures.get(i) + "\n");
            }
        }
        ConcurrentREPL.futures.clear();
    }

    @Override
    protected String processLine(String line) {
        return null;
    }

    private String extractFileName(String command) {
        Pattern pattern = Pattern.compile(">(\\s*)([\\w.-]+)");
        Matcher matcher = pattern.matcher(command);
        if (matcher.find()) {
            return matcher.group(2);
        }
        return null;
    }

}
